/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import BUS.NhanVienBUS;
import DAO.NhanVienDAO;
import DTO.NhanVienDTO;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import javax.swing.JFileChooser;

import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Min-NvT
 */
public class QuanLyNhanVienController {
    private JTable Jtb;
    private JButton BtnSua;
    private JButton BtnXoa;
    private JButton BtnCapNhat;
    private JButton BtnXuatExcel;
    private JButton BtnNhapExcel;
    private JButton BtnThem;
    private JButton BtnTimKiem;
    private JLabel JlbThongBao;
    private JPanel JpnTable;
    boolean khoa = false;
    private JTextField JtfMaNhanVien, JtfHoNhanVien, JtfTenNhanVien, JtfNgaySinh, JtfDiaChi, JtfLuong, JtfKinhNghiem, JtfTimKiem, JtfPhongBan;
    private JComboBox JcbGioiTinh, JcbChucVu;
    private ClassTableModel classTableModel = null;
    private final String[] COLUMNS = {"Mã nhân viên", "Họ", "Tên", "Giới tính", "Ngày Sinh", "Chức vụ", "Lương", "Địa chỉ", "Kinh nghiệm", "Phòng Ban"};
    private NhanVienBUS nhanVienBUS = null;
    private TableRowSorter<TableModel> rowSorter = null;
    public QuanLyNhanVienController(JTable Jtb,JPanel JpnTable, JButton BtnThem, JButton BtnSua, JButton BtnXoa,JButton BtnCapNhat, JButton BtnXuatExcel, JTextField JtfTimKiem, JButton BtnTimKiem,JTextField JtfMaNhanVien, JTextField JtfHoNhanVien, JTextField JtfTenNhanVien,JComboBox JcbGioiTinh, JTextField JtfNgaySinh, JTextField JtfDiaChi, JTextField JtfKinhNghiem, JTextField JtfPhongBan,JComboBox JcbChucVu, JTextField JtfLuong, JLabel JlbThongBao, JButton BtnNhapExcel) {
        this.Jtb=Jtb;
        this.JpnTable = JpnTable;
        this.BtnThem = BtnThem;
        this.BtnSua = BtnSua;
        this.BtnXoa = BtnXoa;
        this.BtnCapNhat = BtnCapNhat;
        this.BtnXuatExcel = BtnXuatExcel;
        this.JtfTimKiem = JtfTimKiem;
        this.BtnTimKiem = BtnTimKiem;
        this.JtfMaNhanVien = JtfMaNhanVien;
        this.JtfHoNhanVien = JtfHoNhanVien;
        this.JtfTenNhanVien = JtfTenNhanVien;
        this.JcbGioiTinh = JcbGioiTinh;
        this.JtfNgaySinh = JtfNgaySinh;
        this.JtfDiaChi = JtfDiaChi;
        this.JcbChucVu = JcbChucVu;
        this.JtfLuong = JtfLuong;
        this.JlbThongBao = JlbThongBao;
        this.BtnNhapExcel = BtnNhapExcel;
        this.JtfKinhNghiem = JtfKinhNghiem;
        this.JtfPhongBan = JtfPhongBan;
        this.classTableModel = new ClassTableModel();
        this.nhanVienBUS = new NhanVienBUS();
    }
    public QuanLyNhanVienController() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public class ClassTableModel {
    public DefaultTableModel setTableNhanVien(ArrayList<NhanVienDTO> listItem, String[] listColumn) {
        int columns = listColumn.length;
        DefaultTableModel dtm = new DefaultTableModel() {
           @Override
            public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 10 ? Boolean.class : String.class;
            }
        };
        dtm.setColumnIdentifiers(listColumn);
        Object[] obj;
        int num = listItem.size();
        NhanVienDTO nhanVienDTO = null;
        for (int i = 0; i < num; i++) {
            nhanVienDTO = listItem.get(i);
            obj = new Object[columns];
            obj[0] = nhanVienDTO.getManv();
            obj[1] = nhanVienDTO.getHo();
            obj[2] = nhanVienDTO.getTen();
            obj[3] = nhanVienDTO.getGioitinh();
            obj[4] = nhanVienDTO.getNgaysinh();
            obj[5] = nhanVienDTO.getChucvu();
            obj[6] = nhanVienDTO.getLuong();
            obj[7] = nhanVienDTO.getDiachi();
            obj[8] = nhanVienDTO.getKinhnghiem();
            obj[9] = nhanVienDTO.getPhongban();
            dtm.addRow(obj);
        }
        return dtm;
    }
    DefaultTableModel setTableNhanVien(ArrayList<NhanVienDTO> listItem, ArrayList<String> COLUMNS) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
    
    public void setDataToTable() {
        ArrayList<NhanVienDTO> listItem = NhanVienBUS.getList();
        DefaultTableModel model = classTableModel.setTableNhanVien(listItem, COLUMNS);
        //JTable table = new JTable(model);
        Jtb.setModel(model);
        Jtb.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        Jtb.getTableHeader().setPreferredSize(new Dimension(100, 50));
        Jtb.getTableHeader().setBackground(Color.red);
        // table.getTableHeader().setBorder();
        Jtb.getTableHeader().setBackground(new Color(232, 57, 99));
        Jtb.getTableHeader().setForeground(Color.WHITE);
        Jtb.setSelectionBackground(new Color(52, 152, 219));
        Jtb.setRowHeight(50);
        Jtb.validate();
        Jtb.repaint();
        Jtb.getColumnModel().getColumn(0).setMaxWidth(100);
        Jtb.getColumnModel().getColumn(0).setMinWidth(90);
        Jtb.getColumnModel().getColumn(0).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(1).setMaxWidth(100);
        Jtb.getColumnModel().getColumn(1).setMinWidth(60);
        Jtb.getColumnModel().getColumn(1).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(2).setMaxWidth(100);
        Jtb.getColumnModel().getColumn(2).setMinWidth(40);
        Jtb.getColumnModel().getColumn(2).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(3).setMaxWidth(100);
        Jtb.getColumnModel().getColumn(3).setMinWidth(40);
        Jtb.getColumnModel().getColumn(3).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(4).setMaxWidth(100);
        Jtb.getColumnModel().getColumn(4).setMinWidth(40);
        Jtb.getColumnModel().getColumn(4).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(5).setMaxWidth(160);
        Jtb.getColumnModel().getColumn(5).setMinWidth(40);
        Jtb.getColumnModel().getColumn(5).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(6).setMaxWidth(100);
        Jtb.getColumnModel().getColumn(6).setMinWidth(40);
        Jtb.getColumnModel().getColumn(6).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(7).setMaxWidth(160);
        Jtb.getColumnModel().getColumn(7).setMinWidth(40);
        Jtb.getColumnModel().getColumn(7).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(8).setMaxWidth(120);
        Jtb.getColumnModel().getColumn(8).setMinWidth(40);
        Jtb.getColumnModel().getColumn(8).setPreferredWidth(40);
        Jtb.getColumnModel().getColumn(9).setMaxWidth(100);
        Jtb.getColumnModel().getColumn(9).setMinWidth(40);
        Jtb.getColumnModel().getColumn(9).setPreferredWidth(40);
       
        JScrollPane scroll = new JScrollPane();
        scroll.getViewport().add(Jtb);

        scroll.setPreferredSize(new Dimension(1100, 400));
        JpnTable.removeAll();
       Jtb.removeAll();
        JpnTable.setLayout(new CardLayout());
       Jtb.setLayout(new CardLayout());
        JpnTable.add(scroll);
        
        JpnTable.validate();
       Jtb.validate();
        JpnTable.repaint();
       Jtb.repaint();
        rowSorter = new TableRowSorter<>(Jtb.getModel());
        Jtb.setRowSorter(rowSorter);
        BtnThem.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                try {
                    JtfMaNhanVien.setEditable(true);
                    if (!checkNotNull()) {
                        JlbThongBao.setText("Nhập thông tin nhân viên!");
                    } else {
                        System.out.println("Kiem tra ma nhan vien da dc them vao dto chua--" + JtfMaNhanVien.getText());
                        NhanVienDTO nhanVienDTO = new NhanVienDTO();
                        nhanVienDTO.setManv(JtfMaNhanVien.getText());
                        nhanVienDTO.setHo(JtfHoNhanVien.getText());
                        nhanVienDTO.setTen(JtfTenNhanVien.getText());
                        nhanVienDTO.setGioitinh(JcbGioiTinh.getSelectedItem().toString());
                        nhanVienDTO.setNgaysinh(JtfNgaySinh.getText());
                        nhanVienDTO.setLuong(JtfLuong.getText());
                        nhanVienDTO.setDiachi(JtfDiaChi.getText());
                        nhanVienDTO.setChucvu(JcbChucVu.getSelectedItem().toString());
                        nhanVienDTO.setKinhnghiem(JtfKinhNghiem.getText());
                        nhanVienDTO.setPhongban(JtfPhongBan.getText());
                        if (YesOrNo()) {
                            int KiemTra = nhanVienBUS.Insert(nhanVienDTO);
                            if (KiemTra != 0) {
                                listItem.add(nhanVienDTO);
                                showResult();
                                JlbThongBao.setText("Thêm thành công.");
                                khoa = false;
                            } else {
                                JlbThongBao.setText("Thêm thất bại");
                            }
                        } else {
                            JlbThongBao.setText("Thao tác thêm đã bị hủy.");
                        }
                    }
                } catch (Exception ex) {
                    JlbThongBao.setText("Kiểm tra kết nối.");
                }
            }
            @Override
            public void mousePressed(MouseEvent e) {
            }
            @Override
            public void mouseReleased(MouseEvent e) {
            }
            private void showResult() {
                {
                    NhanVienDTO s = listItem.get(listItem.size() - 1);
                    model.addRow(new Object[]{
                        s.getManv(), s.getHo(), s.getTen(), s.getGioitinh(), s.getNgaysinh(), s.getChucvu(), s.getLuong(), s.getDiachi(), s.getKinhnghiem(), s.getPhongban()

                    });
                }
            }
        });
        
        BtnXoa.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                try {
                    if (!checkNotNull()) {
                        JlbThongBao.setText("Vui lòng chọn 1 dòng để xóa");
                    } else {
                        String manv = JtfMaNhanVien.getText();
                        NhanVienDTO nhanVienDTO = new NhanVienDTO();
                        if (YesOrNo()) {
                            int KiemTra = nhanVienBUS.Delete(manv);
                            if (KiemTra != 0) {
                                int i = Jtb.getSelectedRow();
                                if (i >= 0) {
                                    model.removeRow(i);
                                    Jtb.setModel(model);Jtb.setModel(model);
                                    JlbThongBao.setText("Xóa thành công.");
                                }
                            } else {
                                JlbThongBao.setText("Lỗi! Xóa thất bại");
                            }
                        } else {
                            JlbThongBao.setText("Thao tác Xóa đã bị hủy.");
                        }
                    }
                } catch (Exception ex) {
                    JlbThongBao.setText("Kiểm tra kết nối.");
                }
            }
            @Override
            public void mousePressed(MouseEvent e) {
            }
            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });
        BtnSua.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                try {
                    if (!checkNotNull()) {
                        JlbThongBao.setText("Vui lòng chọn 1 dòng để cập nhật dữ liệu!");
                    } else {
                        NhanVienDTO nhanVienDTO = new NhanVienDTO();
                        nhanVienDTO.setManv(JtfMaNhanVien.getText());
                        nhanVienDTO.setHo(JtfHoNhanVien.getText());
                        nhanVienDTO.setTen(JtfTenNhanVien.getText());
                        nhanVienDTO.setGioitinh(JcbGioiTinh.getSelectedItem().toString());
                        nhanVienDTO.setNgaysinh(JtfNgaySinh.getText());
                        nhanVienDTO.setChucvu(JcbChucVu.getSelectedItem().toString());
                        nhanVienDTO.setLuong(JtfLuong.getText());
                        nhanVienDTO.setDiachi(JtfDiaChi.getText());
                        nhanVienDTO.setKinhnghiem(JtfKinhNghiem.getText());
                        nhanVienDTO.setPhongban(JtfPhongBan.getText());
                        if (YesOrNo()) {
                            int KiemTra = nhanVienBUS.Update(nhanVienDTO);
                            if (KiemTra != 0) {
                                JlbThongBao.setText("Sửa thành công.");
                                int i = Jtb.getSelectedRow();
                                if (i >= 0) {
                                    model.setValueAt(JtfMaNhanVien.getText(), i, 0);
                                    model.setValueAt(JtfHoNhanVien.getText(), i, 1);
                                    model.setValueAt(JtfTenNhanVien.getText(), i, 2);
                                    model.setValueAt(JcbGioiTinh.getSelectedItem().toString(), i, 3);
                                    model.setValueAt(JtfNgaySinh.getText(), i, 4);
                                    model.setValueAt(JcbChucVu.getSelectedItem().toString(), i, 5);
                                    model.setValueAt(JtfLuong.getText(), i, 6);
                                    model.setValueAt(JtfDiaChi.getText(), i, 7);
                                    model.setValueAt(JtfKinhNghiem.getText(), i, 8);
                                    model.setValueAt(JtfPhongBan.getText(), i, 9);
                                    //table.setModel(model);
                                    Jtb.setModel(model);
                                }
                            } else {
                                JlbThongBao.setText("Lỗi!Sửa");
                            }
                        } else {
                            JlbThongBao.setText("Thao tác đã hủy");
                        }
                    }
                } catch (Exception ex) {
                    JlbThongBao.setText("Kiểm tra kết nối.");
                }
            }
            @Override
            public void mousePressed(MouseEvent e) {
            }
            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });
        BtnCapNhat.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JtfMaNhanVien.setEditable(true);
                khoa = true;
                JtfMaNhanVien.setText("");
                JtfHoNhanVien.setText("");
                JtfTenNhanVien.setText("");
                JtfNgaySinh.setText("");
                JtfLuong.setText("");
                JtfDiaChi.setText("");
                JtfKinhNghiem.setText("");
                JtfPhongBan.setText("");
            }
            @Override
            public void mousePressed(MouseEvent e) {
            }
            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });       
        
       
        Jtb.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && Jtb.getSelectedRow() != -1) {
                    DefaultTableModel model = (DefaultTableModel) Jtb.getModel();
                    int selectedRowIndex = Jtb.getSelectedRow();
                    selectedRowIndex = Jtb.convertRowIndexToModel(selectedRowIndex);
                    NhanVienDTO nhanVienDTO = new NhanVienDTO();
                    nhanVienDTO.setManv(model.getValueAt(selectedRowIndex, 0).toString());
                    nhanVienDTO.setHo(model.getValueAt(selectedRowIndex, 1).toString());
                    nhanVienDTO.setTen(model.getValueAt(selectedRowIndex, 2).toString());
                    nhanVienDTO.setGioitinh(model.getValueAt(selectedRowIndex, 3).toString());
                    nhanVienDTO.setNgaysinh(model.getValueAt(selectedRowIndex, 4).toString());
                    nhanVienDTO.setChucvu(model.getValueAt(selectedRowIndex, 5).toString());
                    nhanVienDTO.setLuong(model.getValueAt(selectedRowIndex, 6).toString());
                    nhanVienDTO.setDiachi(model.getValueAt(selectedRowIndex, 7).toString());
                    nhanVienDTO.setKinhnghiem(model.getValueAt(selectedRowIndex, 8).toString());
                    nhanVienDTO.setPhongban(model.getValueAt(selectedRowIndex, 9).toString());
                    JtfMaNhanVien.setText("" + nhanVienDTO.getManv());
                    JtfMaNhanVien.setEditable(false);
                    JtfHoNhanVien.setText(nhanVienDTO.getHo());
                    JtfTenNhanVien.setText(nhanVienDTO.getTen());
                    JcbGioiTinh.setSelectedItem(nhanVienDTO.getGioitinh());
                    JtfNgaySinh.setText(nhanVienDTO.getNgaysinh());
                    JcbChucVu.setSelectedItem(nhanVienDTO.getChucvu());
                    JtfLuong.setText(nhanVienDTO.getLuong());
                    JtfDiaChi.setText(nhanVienDTO.getDiachi());
                    JtfKinhNghiem.setText(nhanVienDTO.getKinhnghiem());
                    JtfPhongBan.setText(nhanVienDTO.getPhongban());
                    JlbThongBao.setText("Thông tin nhân viên.");
                }
            }
        });
    
    }
     /* public void chonfile(int i){     
            JFileChooser fileChooser =new JFileChooser();
        FileNameExtensionFilter xlsx =new FileNameExtensionFilter("file excel","xlsx");
        fileChooser.setFileFilter(xlsx);
        fileChooser.setMultiSelectionEnabled(false);
        int x =fileChooser.showDialog(i,"chọn file");
        if (x == JFileChooser.APPROVE_OPTION)
        {
            File f =fileChooser.getSelectedFile();
            
        }
            }
     */
    public void setEvent() {
    }
    private boolean checkNotNull() {
        return JtfHoNhanVien.getText() != null && !JtfHoNhanVien.getText().equalsIgnoreCase("")
                && JtfTenNhanVien.getText() != null && !JtfTenNhanVien.getText().equalsIgnoreCase("")
                && JtfMaNhanVien.getText() != null && !JtfMaNhanVien.getText().equalsIgnoreCase("");
    }
    private boolean YesOrNo() {
        int YesOrNo = JOptionPane.showConfirmDialog(null,
                "Bạn muốn cập nhật dữ liệu hay không?", "Thông Báo", JOptionPane.YES_NO_OPTION);
        return YesOrNo == JOptionPane.YES_NO_OPTION;
    }
    private File getFile() {
        JFileChooser fc = new JFileChooser();
        if (JFileChooser.APPROVE_OPTION == fc.showOpenDialog(null)) {
            BtnXuatExcel.setVisible(false);
            return fc.getSelectedFile();
        } else {
            System.out.println("Next time select a file.");
            System.exit(1);
        }
        return null;
    }
   
}
